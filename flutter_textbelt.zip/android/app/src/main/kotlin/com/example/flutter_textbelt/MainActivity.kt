package com.example.flutter_textbelt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
