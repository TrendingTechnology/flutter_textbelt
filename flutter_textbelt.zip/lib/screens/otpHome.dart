import 'package:flutter/material.dart';

class OTPHome extends StatelessWidget {
  const OTPHome({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text("You are Good to go"),
      ),
    );
  }
}
