import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_textbelt/screens/otpHome.dart';
import 'package:pinput/pin_put/pin_put.dart';

import '../api/textbelt.dart';

class OTP extends StatefulWidget {
  const OTP({Key? key}) : super(key: key);

  @override
  _OTPState createState() => _OTPState();
}

class _OTPState extends State<OTP> {
  final mobController = TextEditingController();
  final _otpController = TextEditingController();
  final _pinPutFocusNode = FocusNode();

  final BoxDecoration pinPutDecoration = BoxDecoration(
    color: const Color.fromRGBO(235, 236, 237, 1),
    borderRadius: BorderRadius.circular(5.0),
  );

  String getRandomString(int length) => String.fromCharCodes(Iterable.generate(
      length, (_) => _chars.codeUnitAt(Random().nextInt(_chars.length))));
  final _chars =
      'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';

  String userId = "";

  bool isButton = false;
  bool insertOtp = false;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    userId = getRandomString(15);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Authenticate with Mobile Number",
          style: TextStyle(color: Colors.black),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                insertOtp
                    ? Container(
                        margin: const EdgeInsets.symmetric(vertical: 25),
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: PinPut(
                          withCursor: true,
                          fieldsCount: 6,
                          onChanged: (val) {
                            if (val.length > 5) {
                              setState(() {
                                isButton = true;
                              });
                            } else {
                              setState(() {
                                isButton = false;
                              });
                            }
                          },
                          fieldsAlignment: MainAxisAlignment.spaceAround,
                          textStyle: const TextStyle(
                              fontSize: 25.0, color: Colors.black),
                          eachFieldMargin: EdgeInsets.all(0),
                          eachFieldWidth: 45.0,
                          eachFieldHeight: 55.0,
                          focusNode: _pinPutFocusNode,
                          controller: _otpController,
                          submittedFieldDecoration: pinPutDecoration,
                          selectedFieldDecoration: pinPutDecoration.copyWith(
                            color: Colors.white,
                            border: Border.all(
                              width: 2,
                              color: const Color.fromRGBO(160, 215, 220, 1),
                            ),
                          ),
                          followingFieldDecoration: pinPutDecoration,
                          pinAnimationType: PinAnimationType.scale,
                        ),
                      )
                    : Container(
                        margin: const EdgeInsets.symmetric(vertical: 25),
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: TextFormField(
                          autofocus: true,
                          controller: mobController,
                          keyboardType: TextInputType.number,
                          textAlign: TextAlign.center,
                          maxLength: 10,
                          style: const TextStyle(fontSize: 25),
                          onChanged: (val) {
                            if (val.length > 9) {
                              setState(() {
                                isButton = true;
                              });
                            } else {
                              setState(() {
                                isButton = false;
                              });
                            }
                          },
                          decoration: const InputDecoration(
                            hintText: "Phone Number",
                            prefix: Text("+1"),
                            hintStyle: TextStyle(
                              fontSize: 25,
                              color: Color.fromARGB(255, 200, 200, 200),
                            ),
                          ),
                        ),
                      ),
                ElevatedButton(
                  onPressed: isButton
                      ? insertOtp
                          ? () {
                              setState(() {
                                isLoading = true;
                              });

                              TextBelt.veriOtp(
                                      otp: _otpController.text,
                                      userId: userId,
                                      key: dotenv.env["key"]!)
                                  .then((value) {
                                print(value);
                                setState(() {
                                  isLoading = false;
                                  isButton = false;
                                  insertOtp = false;
                                });
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (builder) => OTPHome()));
                              });
                            }
                          : () {
                              setState(() {
                                isLoading = true;
                              });
                              TextBelt.sendOTP(
                                      phone: mobController.text,
                                      key: dotenv.env["key"]!,
                                      userId: userId)
                                  .then((value) {
                                print(value);
                                setState(() {
                                  isLoading = false;
                                  isButton = false;
                                  insertOtp = true;
                                });
                              });
                            }
                      : null,
                  style: ButtonStyle(
                    padding: !isLoading
                        ? MaterialStateProperty.all(
                            EdgeInsets.symmetric(horizontal: 25, vertical: 5))
                        : MaterialStateProperty.all(EdgeInsets.all(25)),
                    backgroundColor: isButton
                        ? MaterialStateProperty.all(
                            Colors.lightBlue,
                          )
                        : MaterialStateProperty.all(
                            Color.fromARGB(125, 225, 225, 225),
                          ),
                    shape: MaterialStateProperty.all(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(50),
                      ),
                    ),
                  ),
                  child: !isLoading
                      ? Text(
                          insertOtp ? "Verify OTP" : "Send OTP",
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 20),
                        )
                      : CircularProgressIndicator(
                          color: Colors.white,
                        ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
