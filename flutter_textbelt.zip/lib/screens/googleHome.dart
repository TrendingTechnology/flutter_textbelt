import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

class GoogleHome extends StatelessWidget {
  final GoogleSignInAccount user;
  const GoogleHome({Key? key, required this.user}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    print(user);
    return Container();
  }
}
