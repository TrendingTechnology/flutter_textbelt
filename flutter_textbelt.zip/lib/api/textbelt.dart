import 'dart:io';

import 'package:http/http.dart' as http;

class TextBelt {
  static sendOTP({
    required String phone,
    required String userId,
    required String key,
  }) async {
    try {
      var response = await http.post(
        Uri.parse(Uri.encodeFull('https://textbelt.com/otp/generate')),
        headers: {"Accept": "application/json"},
        body: {
          "phone": phone,
          "userid": userId,
          "key": key,
        },
      );
      print(response.body);
      return response.body;
    } on SocketException {
      return {
        "success": "Internet Issue",
        "message": "No Internet connection 😑"
      };
    } on HttpException {
      return {
        "success": "Post Problem",
        "message": "Couldn't find the post 😱"
      };
    } on FormatException {
      return {"success": "Format Issue", "message": "Bad response format 👎"};
    }
  }

  static veriOtp({
    required String otp,
    required String userId,
    required String key,
  }) async {
    try {
      final verifyURLOTP =
          "https://textbelt.com/otp/verify?otp=$otp&userid=$userId&key=$key";

      var response = await http.get(
        Uri.parse(Uri.encodeFull(verifyURLOTP)),
        headers: {"Accept": "application/json"},
      );
      print(response.body);
      return response.body;
    } on SocketException {
      return {
        "success": "Internet Issue",
        "isValidOtp": "No Internet connection 😑"
      };
    } on HttpException {
      return {
        "success": "Post Problem",
        "isValidOtp": "Couldn't find the post 😱"
      };
    } on FormatException {
      return {
        "success": "Format Issue",
        "isValidOtp": "Bad response format 👎"
      };
    }
  }
}
